-- Проверка: все курсы с преподавателями
SELECT c.Title, u.FullName AS Instructor
FROM catalog.Courses c
JOIN core.Instructors i ON c.InstructorID = i.InstructorID
JOIN core.Users u ON i.UserID = u.UserID;

-- Проверка: выручка по курсам
SELECT * FROM report.v_RevenueByCourse;

-- Проверка: прогресс студента
SELECT * FROM report.v_StudentProgress;