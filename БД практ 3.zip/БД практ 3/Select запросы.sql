USE CompanyRelations;
GO

SELECT * FROM Departments;
SELECT * FROM Employees;
SELECT * FROM Projects;
GO

SELECT
    e.EmployeeID,
    e.FullName,
    e.DepartmentID,
    d.DepartmentName,
    d.Manager
FROM Employees AS e
LEFT JOIN Departments AS d
    ON e.DepartmentID = d.DepartmentID;
GO

SELECT
    e.EmployeeID,
    e.FullName,
    e.DepartmentID,
    d.DepartmentName
FROM Employees AS e
LEFT JOIN Departments AS d
    ON e.DepartmentID = d.DepartmentID
WHERE d.DepartmentName IS NULL;
GO

SELECT
    d.DepartmentID,
    d.DepartmentName,
    d.Manager,
    e.EmployeeID,
    e.FullName,
    e.Salary
FROM Employees AS e
RIGHT JOIN Departments AS d
    ON e.DepartmentID = d.DepartmentID;
GO

SELECT
    d.DepartmentID,
    d.DepartmentName,
    d.Manager
FROM Employees AS e
RIGHT JOIN Departments AS d
    ON e.DepartmentID = d.DepartmentID
WHERE e.EmployeeID IS NULL;
GO

SELECT
    d.DepartmentName,
    COUNT(e.EmployeeID) AS EmployeeCount
FROM Employees AS e
RIGHT JOIN Departments AS d
    ON e.DepartmentID = d.DepartmentID
GROUP BY d.DepartmentName;
GO

SELECT DepartmentID, DepartmentName FROM Departments;
SELECT DISTINCT DepartmentID FROM Employees;
SELECT DISTINCT DepartmentID FROM Projects;
GO

SELECT
    EmployeeID,
    FullName,
    DepartmentID
FROM Employees
WHERE DepartmentID IS NULL;
GO

SELECT
    e.EmployeeID,
    e.FullName,
    e.DepartmentID
FROM Employees AS e
LEFT JOIN Departments AS d
    ON e.DepartmentID = d.DepartmentID
WHERE e.DepartmentID IS NOT NULL
    AND d.DepartmentID IS NULL;
GO

SELECT
    d.DepartmentID,
    d.DepartmentName,
    d.Manager
FROM Employees AS e
RIGHT JOIN Departments AS d
    ON e.DepartmentID = d.DepartmentID
WHERE e.EmployeeID IS NULL;
GO

SELECT
    p.ProjectID,
    p.ProjectName,
    p.DepartmentID
FROM Projects AS p
LEFT JOIN Departments AS d
    ON p.DepartmentID = d.DepartmentID
WHERE d.DepartmentID IS NULL;
GO

SELECT
    d.DepartmentID,
    d.DepartmentName
FROM Projects AS p
RIGHT JOIN Departments AS d
    ON p.DepartmentID = d.DepartmentID
WHERE p.ProjectID IS NULL;
GO

SELECT
    e.EmployeeID,
    e.FullName,
    e.DepartmentID AS EmpDept,
    d.DepartmentID AS DeptID,
    d.DepartmentName
FROM Employees AS e
FULL JOIN Departments AS d
    ON e.DepartmentID = d.DepartmentID
WHERE e.DepartmentID IS NULL
    OR d.DepartmentID IS NULL;
GO

SELECT
    e.EmployeeID,
    e.FullName,
    e.DepartmentID,
    CASE
        WHEN e.DepartmentID IS NULL THEN 'Отсутствует отдел (NULL)'
        WHEN d.DepartmentID IS NULL THEN 'Несуществующий отдел'
        ELSE 'Связь корректна'
    END AS IntegrityStatus
FROM Employees AS e
LEFT JOIN Departments AS d
    ON e.DepartmentID = d.DepartmentID;
GO

SELECT
    COUNT(*) AS BrokenLinksCount
FROM Employees AS e
LEFT JOIN Departments AS d
    ON e.DepartmentID = d.DepartmentID
WHERE (e.DepartmentID IS NOT NULL AND d.DepartmentID IS NULL)
    OR (e.DepartmentID IS NULL);
GO

SELECT
    e.EmployeeID,
    e.FullName,
    e.DepartmentID,
    d.DepartmentName
FROM Employees AS e
LEFT JOIN Departments AS d
    ON e.DepartmentID = d.DepartmentID
WHERE e.DepartmentID IS NOT NULL
    AND d.DepartmentID IS NULL;
GO

SELECT
    e.EmployeeID,
    e.FullName,
    e.DepartmentID,
    d.DepartmentName
FROM Employees AS e
LEFT JOIN Departments AS d
    ON e.DepartmentID = d.DepartmentID;
GO

SELECT
    DepartmentName,
    COUNT(*) AS DuplicateCount
FROM Departments
GROUP BY DepartmentName
HAVING COUNT(*) > 1;
GO

SELECT
    'Employees → Departments' AS Relation,
    COUNT(*) AS BrokenLinks
FROM Employees e
LEFT JOIN Departments d ON e.DepartmentID = d.DepartmentID
WHERE e.DepartmentID IS NOT NULL AND d.DepartmentID IS NULL

UNION ALL

SELECT
    'Projects → Departments' AS Relation,
    COUNT(*) AS BrokenLinks
FROM Projects p
LEFT JOIN Departments d ON p.DepartmentID = d.DepartmentID
WHERE p.DepartmentID IS NOT NULL AND d.DepartmentID IS NULL;
GO

SELECT
    d.DepartmentName,
    COUNT(DISTINCT e.EmployeeID) AS EmployeesCount,
    COUNT(DISTINCT p.ProjectID) AS ProjectsCount
FROM Departments d
LEFT JOIN Employees e ON d.DepartmentID = e.DepartmentID
LEFT JOIN Projects p ON d.DepartmentID = p.DepartmentID
GROUP BY d.DepartmentName;
GO

SELECT
    DepartmentID,
    DepartmentName,
    Manager,
    ROW_NUMBER() OVER (PARTITION BY DepartmentName ORDER BY DepartmentID) AS RowNum
FROM Departments;
GO

SELECT
    (SELECT COUNT(*) FROM Departments) AS TotalDepartments,
    (SELECT COUNT(*) FROM Employees) AS TotalEmployees,
    (SELECT COUNT(*) FROM Projects) AS TotalProjects;
GO

SELECT
    f.name AS ForeignKey,
    OBJECT_NAME(f.parent_object_id) AS TableName,
    COL_NAME(fc.parent_object_id, fc.parent_column_id) AS ColumnName,
    OBJECT_NAME(f.referenced_object_id) AS ReferencedTable
FROM sys.foreign_keys AS f
INNER JOIN sys.foreign_key_columns AS fc
    ON f.OBJECT_ID = fc.constraint_object_id;
GO