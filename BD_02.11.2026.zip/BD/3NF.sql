-- Исходная таблица с транзитивной зависимостью
CREATE TABLE students_3nf_raw (
    student_id    INTEGER PRIMARY KEY,
    full_name     VARCHAR(100) NOT NULL,
    group_name    VARCHAR(20)  NOT NULL,
    curator_name  VARCHAR(100) NOT NULL,
    curator_phone VARCHAR(20)  NOT NULL
);

INSERT INTO students_3nf_raw (student_id, full_name, group_name, curator_name, curator_phone)
SELECT student_id, full_name, group_name, 'Смирнов Андрей Петрович', '+7-900-123-45-67'
FROM students_2nf;

-- Таблица кураторов
CREATE TABLE curators_3nf (
    curator_id    SERIAL PRIMARY KEY,
    curator_name  VARCHAR(100) NOT NULL,
    curator_phone VARCHAR(20)  NOT NULL,
    UNIQUE (curator_name, curator_phone)
);

-- Справочник групп
CREATE TABLE groups_3nf (
    group_id   SERIAL PRIMARY KEY,
    group_name VARCHAR(20) NOT NULL UNIQUE,
    curator_id INTEGER NOT NULL,
    FOREIGN KEY (curator_id) REFERENCES curators_3nf(curator_id)
);

-- Новая таблица студентов
CREATE TABLE students_3nf (
    student_id INTEGER PRIMARY KEY,
    full_name  VARCHAR(100) NOT NULL,
    group_id   INTEGER NOT NULL,
    FOREIGN KEY (group_id) REFERENCES groups_3nf(group_id)
);

-- Таблица связей с дисциплинами
CREATE TABLE enrollments_3nf (
    student_id INTEGER NOT NULL,
    subject_id INTEGER NOT NULL,
    PRIMARY KEY (student_id, subject_id),
    FOREIGN KEY (student_id) REFERENCES students_3nf(student_id),
    FOREIGN KEY (subject_id) REFERENCES subjects_2nf(subject_id)
);

-- Перенос данных
INSERT INTO curators_3nf (curator_name, curator_phone)
SELECT DISTINCT curator_name, curator_phone FROM students_3nf_raw;

INSERT INTO groups_3nf (group_name, curator_id)
SELECT DISTINCT s.group_name, c.curator_id
FROM students_3nf_raw AS s
JOIN curators_3nf AS c ON s.curator_name = c.curator_name
                       AND s.curator_phone = c.curator_phone;

INSERT INTO students_3nf (student_id, full_name, group_id)
SELECT s.student_id, s.full_name, g.group_id
FROM students_3nf_raw AS s
JOIN groups_3nf AS g ON s.group_name = g.group_name;

INSERT INTO enrollments_3nf (student_id, subject_id)
SELECT student_id, subject_id FROM enrollments_2nf;

-- Полный электронный журнал
SELECT s.student_id, s.full_name, g.group_name, c.curator_name, d.subject_name
FROM students_3nf AS s
JOIN groups_3nf   AS g ON s.group_id  = g.group_id
JOIN curators_3nf AS c ON g.curator_id = c.curator_id
JOIN enrollments_3nf AS e ON s.student_id = e.student_id
JOIN subjects_2nf AS d ON e.subject_id = d.subject_id
ORDER BY s.student_id, d.subject_name;