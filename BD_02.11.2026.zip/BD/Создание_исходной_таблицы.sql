CREATE TABLE students_raw (
    id SERIAL PRIMARY KEY,
    full_name VARCHAR(100),
    group_name VARCHAR(20),
    subjects TEXT
);

INSERT INTO students_raw (full_name, group_name, subjects) VALUES
('Иванов Иван',       'ИСП2111', 'Базы данных, Python, Java'),
('Петров Пётр',       'ИСП2111', 'Базы данных, Python'),
('Сидоров Алексей',   'ИСП2111', 'Java, Python'),
('Смирнова Анна',     'ИСП2111', 'Базы данных, Java'),
('Кузнецов Максим',   'ИСП2111', 'Python, Базы данных, Java');

SELECT * FROM students_raw ORDER BY id;