
CREATE TABLE students_2nf (
    student_id INTEGER PRIMARY KEY,
    full_name  VARCHAR(100) NOT NULL,
    group_name VARCHAR(20)  NOT NULL
);


CREATE TABLE subjects_2nf (
    subject_id   SERIAL PRIMARY KEY,
    subject_name VARCHAR(100) NOT NULL UNIQUE
);


CREATE TABLE enrollments_2nf (
    student_id INTEGER NOT NULL,
    subject_id INTEGER NOT NULL,
    PRIMARY KEY (student_id, subject_id),
    FOREIGN KEY (student_id) REFERENCES students_2nf(student_id),
    FOREIGN KEY (subject_id) REFERENCES subjects_2nf(subject_id)
);


INSERT INTO students_2nf (student_id, full_name, group_name)
SELECT DISTINCT student_id, full_name, group_name FROM students_1nf;

INSERT INTO subjects_2nf (subject_name)
SELECT DISTINCT subject_name FROM students_1nf ORDER BY subject_name;

INSERT INTO enrollments_2nf (student_id, subject_id)
SELECT s.student_id, d.subject_id
FROM students_1nf AS s
JOIN subjects_2nf AS d ON s.subject_name = d.subject_name;


SELECT * FROM students_2nf ORDER BY student_id;
SELECT * FROM subjects_2nf ORDER BY subject_id;
SELECT * FROM enrollments_2nf ORDER BY student_id, subject_id;


SELECT s.student_id, s.full_name, s.group_name, d.subject_name
FROM enrollments_2nf AS e
JOIN students_2nf  AS s ON e.student_id = s.student_id
JOIN subjects_2nf  AS d ON e.subject_id = d.subject_id
ORDER BY s.student_id, d.subject_name;