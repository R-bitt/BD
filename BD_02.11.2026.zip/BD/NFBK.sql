-- Исходная таблица
CREATE TABLE teaching_raw (
    subject_name VARCHAR(100) NOT NULL,
    classroom    VARCHAR(20)  NOT NULL,
    teacher_name VARCHAR(100) NOT NULL,
    PRIMARY KEY (subject_name, classroom),
    UNIQUE (teacher_name, classroom)
);

INSERT INTO teaching_raw (subject_name, classroom, teacher_name) VALUES
('Базы данных', '201', 'Иванов И.И.'),
('Базы данных', '202', 'Иванов И.И.'),
('Базы данных', '203', 'Петров П.П.'),
('Python',      '301', 'Сидоров А.А.'),
('Python',      '302', 'Сидоров А.А.'),
('Java',        '401', 'Смирнова Е.В.'),
('Java',        '402', 'Смирнова Е.В.'),
('Java',        '403', 'Кузнецов М.С.');

-- Справочник закрепления преподавателей
CREATE TABLE teacher_subjects_bcnf (
    teacher_name VARCHAR(100) PRIMARY KEY,
    subject_name VARCHAR(100) NOT NULL
);

-- Таблица назначений аудиторий
CREATE TABLE classroom_assignments_bcnf (
    teacher_name VARCHAR(100) NOT NULL,
    classroom    VARCHAR(20)  NOT NULL,
    PRIMARY KEY (teacher_name, classroom),
    FOREIGN KEY (teacher_name) REFERENCES teacher_subjects_bcnf(teacher_name)
);

-- Перенос данных
INSERT INTO teacher_subjects_bcnf (teacher_name, subject_name)
SELECT DISTINCT teacher_name, subject_name FROM teaching_raw;

INSERT INTO classroom_assignments_bcnf (teacher_name, classroom)
SELECT DISTINCT teacher_name, classroom FROM teaching_raw;

-- Восстановление исходных данных
SELECT t.subject_name, a.classroom, t.teacher_name
FROM classroom_assignments_bcnf AS a
JOIN teacher_subjects_bcnf AS t ON a.teacher_name = t.teacher_name
ORDER BY t.subject_name, a.classroom;

-- Демонстрация устранения аномалии обновления
BEGIN;
UPDATE teacher_subjects_bcnf
SET subject_name = 'Проектирование БД'
WHERE teacher_name = 'Иванов И.И.';

SELECT t.teacher_name, t.subject_name, a.classroom
FROM teacher_subjects_bcnf AS t
JOIN classroom_assignments_bcnf AS a ON t.teacher_name = a.teacher_name
WHERE t.teacher_name = 'Иванов И.И.' ORDER BY a.classroom;
ROLLBACK;  -- откат

-- Итоговый отчёт
SELECT t.teacher_name, t.subject_name,
       COUNT(a.classroom) AS classrooms_count,
       STRING_AGG(a.classroom, ', ' ORDER BY a.classroom) AS classrooms
FROM teacher_subjects_bcnf AS t
JOIN classroom_assignments_bcnf AS a ON t.teacher_name = a.teacher_name
GROUP BY t.teacher_name, t.subject_name
ORDER BY t.teacher_name;