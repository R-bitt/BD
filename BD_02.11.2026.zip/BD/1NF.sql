CREATE TABLE students_1nf (
    record_id   SERIAL PRIMARY KEY,
    student_id  INTEGER NOT NULL,
    full_name   VARCHAR(100) NOT NULL,
    group_name  VARCHAR(20)  NOT NULL,
    subject_name VARCHAR(100) NOT NULL,
    UNIQUE (student_id, subject_name)
);

INSERT INTO students_1nf (student_id, full_name, group_name, subject_name)
SELECT s.id, s.full_name, s.group_name, TRIM(t.subject)
FROM students_raw AS s
CROSS JOIN LATERAL string_to_table(s.subjects, ',') AS t(subject);

SELECT student_id, full_name, group_name, subject_name
FROM students_1nf ORDER BY student_id, subject_name;

SELECT COUNT(*) AS total_records FROM students_1nf;