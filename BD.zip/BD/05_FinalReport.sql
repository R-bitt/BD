USE TechServiceDB;
GO

WITH OrderStats AS (
    SELECT BranchID, COUNT(OrderID) AS TotalOrders,
        SUM(CASE WHEN Status='Завершен' THEN 1 ELSE 0 END) AS CompletedOrders,
        SUM(CASE WHEN Status='В работе' THEN 1 ELSE 0 END) AS InProgressOrders,
        AVG(TotalCost) AS AvgCheck
    FROM RepairOrders GROUP BY BranchID
),
PaymentStats AS (
    SELECT o.BranchID, SUM(p.Amount) AS Revenue
    FROM Payments p JOIN RepairOrders o ON p.OrderID = o.OrderID GROUP BY o.BranchID
)
SELECT b.BranchName AS [Филиал], ISNULL(os.TotalOrders,0) AS [Всего заказов],
    ISNULL(os.CompletedOrders,0) AS [Завершено], ISNULL(os.InProgressOrders,0) AS [В работе],
    ISNULL(ps.Revenue,0) AS [Выручка, руб.], ISNULL(os.AvgCheck,0) AS [Средний чек, руб.]
FROM Branches b
LEFT JOIN OrderStats os ON b.BranchID = os.BranchID
LEFT JOIN PaymentStats ps ON b.BranchID = ps.BranchID
ORDER BY [Выручка, руб.] DESC;

GO