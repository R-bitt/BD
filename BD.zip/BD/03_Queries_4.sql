USE TechServiceDB;
GO

-- Задание 6
WITH AvgOrders AS (SELECT AVG(Cnt) AS AvgCnt FROM (SELECT COUNT(*) AS Cnt FROM RepairOrders GROUP BY EmployeeID) t)
SELECT e.FullName, COUNT(o.OrderID) AS Cnt FROM Employees e JOIN RepairOrders o ON e.EmployeeID = o.EmployeeID GROUP BY e.FullName HAVING COUNT(o.OrderID) > (SELECT AvgCnt FROM AvgOrders);

WITH ClientSums AS (SELECT ClientID, SUM(TotalCost) AS SumCost FROM RepairOrders GROUP BY ClientID)
SELECT c.FullName, cs.SumCost FROM Clients c JOIN ClientSums cs ON c.ClientID = cs.ClientID WHERE cs.SumCost > (SELECT AVG(SumCost) FROM ClientSums);

SELECT * FROM Services WHERE Price > (SELECT AVG(Price) FROM Services);

SELECT TOP 1 c.FullName, COUNT(o.OrderID) AS Cnt FROM Clients c JOIN RepairOrders o ON c.ClientID = o.ClientID GROUP BY c.FullName ORDER BY Cnt DESC;

SELECT o.OrderID, o.TotalCost, SUM(p.Amount) AS Paid FROM RepairOrders o JOIN Payments p ON o.OrderID = p.OrderID GROUP BY o.OrderID, o.TotalCost HAVING SUM(p.Amount) < o.TotalCost;
GO