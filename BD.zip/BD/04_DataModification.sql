USE TechServiceDB;
GO

UPDATE Services SET Price = Price * 1.15 WHERE Category = 'Диагностика';
PRINT 'Ситуация 1: ' + CAST(@@ROWCOUNT AS NVARCHAR);

UPDATE RepairOrders SET Status = 'Завершен', CompletionDate = GETDATE() WHERE OrderID = 10;
PRINT 'Ситуация 2: ' + CAST(@@ROWCOUNT AS NVARCHAR);

UPDATE Clients SET Phone = '9999999999' WHERE ClientID = 1;
PRINT 'Ситуация 3: ' + CAST(@@ROWCOUNT AS NVARCHAR);

DELETE FROM Services WHERE ServiceID = 999 AND NOT EXISTS (SELECT 1 FROM RepairOrders WHERE ServiceID = 999);
PRINT 'Ситуация 4: ' + CAST(@@ROWCOUNT AS NVARCHAR);
GO