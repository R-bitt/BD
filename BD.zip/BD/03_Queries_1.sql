USE TechServiceDB;
GO

-- Задание 3
SELECT * FROM Clients ORDER BY FullName;
SELECT * FROM Services WHERE Price > 3000;
SELECT * FROM RepairOrders WHERE OrderDate >= DATEADD(day,-30,GETDATE());
SELECT * FROM RepairOrders WHERE Status IN ('В работе','Ожидает запчасти');
SELECT TOP 5 * FROM Services ORDER BY Price DESC;
SELECT * FROM Clients WHERE FullName LIKE 'С%';
SELECT * FROM RepairOrders WHERE TotalCost BETWEEN 2000 AND 10000;
SELECT * FROM Devices WHERE Brand = 'Lenovo';
SELECT * FROM RepairOrders WHERE Status != 'Завершен';
SELECT * FROM RepairOrders WHERE CompletionDate IS NULL;