USE TechServiceDB;
GO

-- Задание 5
SELECT COUNT(*) AS TotalOrders FROM RepairOrders;
SELECT AVG(TotalCost) AS AvgCost FROM RepairOrders;
SELECT MIN(TotalCost) AS MinCost, MAX(TotalCost) AS MaxCost FROM RepairOrders;
SELECT Status, COUNT(*) AS Cnt FROM RepairOrders GROUP BY Status;
SELECT SUM(Amount) AS TotalRevenue FROM Payments;
SELECT TOP 1 b.BranchName, COUNT(o.OrderID) AS Cnt FROM Branches b JOIN RepairOrders o ON b.BranchID = o.BranchID GROUP BY b.BranchName ORDER BY Cnt DESC;
SELECT e.FullName, COUNT(o.OrderID) AS Cnt FROM Employees e LEFT JOIN RepairOrders o ON e.EmployeeID = o.EmployeeID GROUP BY e.FullName;
SELECT c.FullName, COUNT(o.OrderID) AS Cnt FROM Clients c JOIN RepairOrders o ON c.ClientID = o.ClientID GROUP BY c.FullName HAVING COUNT(o.OrderID) > 2;
SELECT TOP 3 s.ServiceName, COUNT(o.OrderID) AS Cnt FROM Services s JOIN RepairOrders o ON s.ServiceID = o.ServiceID GROUP BY s.ServiceName ORDER BY Cnt DESC;
SELECT b.BranchName, SUM(p.Amount) AS Revenue FROM Branches b JOIN RepairOrders o ON b.BranchID = o.BranchID JOIN Payments p ON o.OrderID = p.OrderID GROUP BY b.BranchName;