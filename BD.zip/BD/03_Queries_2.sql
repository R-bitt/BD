USE TechServiceDB;
GO

-- Задание 4
SELECT o.OrderID, c.FullName AS Client, d.Model AS Device, s.ServiceName, e.FullName AS Employee, o.OrderDate, o.Status, o.TotalCost
FROM RepairOrders o
JOIN Clients c ON o.ClientID = c.ClientID
JOIN Devices d ON o.DeviceID = d.DeviceID
JOIN Services s ON o.ServiceID = s.ServiceID
JOIN Employees e ON o.EmployeeID = e.EmployeeID;

SELECT b.BranchName, b.Address, e.FullName AS Employee, o.OrderID
FROM Branches b
LEFT JOIN Employees e ON b.BranchID = e.BranchID
LEFT JOIN RepairOrders o ON e.EmployeeID = o.EmployeeID;

SELECT c.FullName, d.Model, o.OrderID, o.OrderDate, o.Status, s.ServiceName
FROM Clients c
JOIN Devices d ON c.ClientID = d.ClientID
JOIN RepairOrders o ON d.DeviceID = o.DeviceID
JOIN Services s ON o.ServiceID = s.ServiceID
WHERE c.ClientID = 1;

SELECT s.* FROM Services s LEFT JOIN RepairOrders o ON s.ServiceID = o.ServiceID WHERE o.OrderID IS NULL;
SELECT c.* FROM Clients c LEFT JOIN RepairOrders o ON c.ClientID = o.ClientID WHERE o.OrderID IS NULL;
